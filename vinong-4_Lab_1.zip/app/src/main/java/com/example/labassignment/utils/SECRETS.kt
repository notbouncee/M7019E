package com.example.labassignment.utils

object SECRETS {
    const val API_KEY = "d6157b8c7dc2ac66eccfaddc44bea25a"
}