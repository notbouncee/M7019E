package com.example.labassignment.database

import com.example.labassignment.model.Movie

data class MovieDBUIState (
    val selectedMovie: Movie? = null
)